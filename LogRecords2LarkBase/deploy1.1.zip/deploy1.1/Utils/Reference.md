Từng làm: 
1. https://github.com/DoanNgocCuong/MiniProd_WebTestScoring/blob/main/User_TakeTesting/deploy4.5_FixF5From4.3/backend_package/larkbase_operations.py

2. https://github.com/DoanNgocCuong/MiniProd_UIChatbot_throughCallAPI/blob/main/APIBasicRAG_chatbot/deploy2/backend_package/get_tenantAccessToken_funct.py