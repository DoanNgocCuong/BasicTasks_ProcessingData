# config.py
APP_DOANNGOCCUONG_ID="cli_a7852e8dc6fc5010"
APP_DOANNGOCCUONG_SECRET="6SIj0RfQ0ZwROvUhkjAwLebhLfJkIwnT"

APP_BASE_TOKEN = "O3EybGW4TaQ1SusAtukl9RXzgJd" # app_token là mã định danh của ứng dụng Base
BASE_TABLE_ID = "tblwZ1BvvVgP4Ot7" # table_id là mã định danh của bảng trong Base

